<!DOCTYPE html>
<html>
<link rel="stylesheet" type="text/css" href="one.css?v=<?php echo time(); ?>">
<head>
  <title></title>
</head>
<body>
  <header>
  <div class='faq'>

    <input id='faq-a' type='checkbox'>
    <label for='faq-a'>
    <p class="faq-heading">What is Extrack?</p>
    <div class='faq-arrow'></div>
      <p class="faq-text">  Extrack is a  personal finance tracker app Currently available on the world wide web. </p>
    </label>

    <input id='faq-b' type='checkbox'>
    <label for='faq-b'>
    <p class="faq-heading">Is Extrack Secure and Private?</p>
    <div class='faq-arrow'></div>
      <p class="faq-text">Absolutely. We have the utmost respect for your privacy. Your information is safe and secure with Extrack as We consider Privacy as one of the main concern. Yes, your data is safe with Extrack. We use Secure Sockets Layer (SSL) Certificate Authority for enabling secure e-commerce and interactions over the Internet. </p>
    </label>

    <input id='faq-c' type='checkbox'>
    <label for='faq-c'>
    <p class="faq-heading"> How do I sign up?</p>
    <div class='faq-arrow'></div>
      <p class="faq-text">Fill out the details in the signup option in the navigation menu and after you press the sign up button  you'll get a verification code on your phone</p>
    </label>

    <input id='faq-d' type='checkbox'>
    <label for='faq-d'>
    <p class="faq-heading"> What are the system requirements?</p>
    <div class='faq-arrow'></div>
      <p class="faq-text">If you are reading this page, you probably already have them. Since Extrack is an online service, it can be accessed from anywhere you can get an Internet connection. We recommend using Microsoft Edge, Google Chrome, Firefox, or Safari to access our system. Other browser varieties may work as well. </p>
    </label>

   <input id='faq-e' type='checkbox'>
    <label for='faq-e'>
    <p class="faq-heading">How do I create a budget?</p>
    <div class='faq-arrow'></div>
      <p class="faq-text">The first step in creating a budget is to set your personal goals. You can create monthly budgets by tapping on 'set budgets' in the dashboard.</p>
    </label>


    <input id='settings' type='checkbox'>
    <input id='faq-f' type='checkbox'>
    <label for='faq-f'>
    <p class="faq-heading"> Does ExTrack require my bank account information?</p>
    <div class='faq-arrow'></div>
      <p class="faq-text">No, you do not have to provide your personal bank account or credit card information to use our service. You can name your bank accounts as you like in our system, and import financial data provided from your bank without identifying the important account information that you should always safeguard and keep private</p>
    </label>
  </div>


  <a href="../dashboard.php"> <input type="button" value="Back to Dashboard"> </a>
  
</header>
</body>
</html>