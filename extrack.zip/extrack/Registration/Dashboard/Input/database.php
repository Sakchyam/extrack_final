<?php

$conn = mysqli_connect('localhost', 'root', '', 'registration');

if(!$conn){
   die('Could not Connect My Sql:' .mysql_error());
   }

?>
