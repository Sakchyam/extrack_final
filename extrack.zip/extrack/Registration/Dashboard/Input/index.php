<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Extrack App</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body>
   
    <div class="budget-container">
        <div class="app-title">
            
        </div>
        <div class="budget-header">
            <div class="balance">
                <div class="title">
                    Balance
                </div>
                <div class="value">
                    <small>$</small>0
                </div>
            </div>
            <div class="account">
                <div class="income">
                    <div class="title">
                        Income
                    </div>
                    <div class="income-total">
                        <small>Rs</small>0
                    </div>
                </div>
                <div class="chart"></div>
                <div class="outcome">
                    <div class="title">
                        Expense
                    </div>
                    <div class="outcome-total">
                        <small>Rs</small>0
                    </div>
                </div>
            </div>
        </div>
        <div class="budget-dashboard">
            <div class="dash-title">Transaction History</div>
            <div class="toggle">
                <div class="tab1">Expenses</div>
                <div class="tab2">Income</div>
                <div class="tab3 active">All</div>
            </div>
            <br>
            <div class="hide" id="income">
                <ul class="list"></ul>
                    <div class="input">
                    <form method="post" action="../../process.php" >
                    <input type="text" id="income-title-input" name="title" placeholder="Title">
                    <input type="number" id="income-amount-input" name="amount" placeholder="Rs. 0">
                    <div class="add-income" type = "submit"> <img src="icon/plas.png" alt=""></div>
                    <br>
                    <input type="submit" value="Save in cloud" name="save">
                     </form>                  
                    
                    
                </div>
            </div>
            <div class="hide" id="expense">
                <ul class="list"></ul>
                <div class="input">
                    <form method="post" action="../../pro2.php" >
                    <input type="text" id="expense-title-input" name="title" placeholder="Title">
                    <input type="number" id="expense-amount-input" name="amount" placeholder="Rs. 0">
                    <div class="add-expense"><img src="icon/plas.png" alt=""></div>
                    <br>
                    <input type="submit" value="Save in cloud" name="save">
                     </form>   
                </div>
            </div>
            <div id="all">
                <ul class="list"></ul>
            </div>
        </div>
    </div>
    
<a href="../dashboard.php"> <input type="button" value="Back to Dashboard"> </a>

    <script src="chart.js"></script>
    <script src="budget.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/darkmode-js@1.5.5/lib/darkmode-js.min.js"></script>
    <script src="script.js"></script>


</body>
</html>