<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="load.css?v=<?php echo time(); ?>">
	<title></title>
</head>
<body>

<div class="container">
	<div class="green"></div>
	<div class="white"></div>
	<div class="black"></div>
	<div class="grey"></div>
</div>
</body>


<script>
    setTimeout(function(){
       window.location.href = 'index.php';
    }, 2000);
</script>

</html>