<?php

include_once 'database.php';
if(isset($_POST['save']))
{	 
	 $title = $_POST['title'];
	 $amount = $_POST['amount'];

	 $sql = "INSERT INTO income (title, amount) 
  			  VALUES('$title', '$amount')";

	 if (mysqli_query($conn, $sql)) {
		readfile("C:\xampp\htdocs\extrack\Registration\Dashboard\Input");
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}

?>