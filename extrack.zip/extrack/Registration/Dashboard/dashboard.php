<!DOCTYPE html>
<html>
<head>
  <title></title>
<link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
<script src="https://kit.fontawesome.com/6578ce1a1c.js" crossorigin="anonymous">
</script>

</head>
<body>
<header>
<div class="wrapper">
<div class="sidebar">
  <h1> <spam style="color: green; font-family: 'Open Sans', sans-serif;">Ex</spam>Track </h1>
  <ul>
    <li><a href="Input\load.php"><i class="fas fa-keyboard"> </i> Input Data </a></li>
      <li><a href="profilecard.php"><i class="fas fa-university"> </i> Statement </a> </li>
        <li><a href="FAQ\faq1.php"><i class="fas fa-question-circle"> </i> Help </a></li>
         <li><a href="../../index.html"><i class="fa fa-sign-out" aria-hidden="true"> </i>  Log Out </a></li>

    </ul>
</div>
</div>

<div class="title">
  <span class="text1"><i>WELCOME TO </i></span> 
  <span class="text2">ExTrack</span>
</div>
</header>
</body>
</html>