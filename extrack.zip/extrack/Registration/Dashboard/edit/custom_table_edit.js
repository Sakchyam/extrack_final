$(document).ready(function(){
	$('#data_table').Tabledit({
		deleteButton: true,
		editButton: true,   		
		columns: {
		  identifier: [0, 'id'],                    
		  editable: [[1, 'title'], [2, 'amount']]
		},
		hideIdentifier: true,
		url: 'live_edit.php'		
	});
});