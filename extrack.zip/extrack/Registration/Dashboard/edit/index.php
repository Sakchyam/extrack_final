<?php 
include_once("db_connect.php");
include("header.php"); 
?>
<title> Table Edit</title>
<script type="text/javascript" src="dist/jquery.tabledit.js"></script>
<script type="text/javascript" src="custom_table_edit.js"></script>

<?php include('container.php');?>
<div class="container home">	
	<h2>Expense Table</h2>		 
	<table id="data_table" class="table table-striped">
		<thead>
			<tr>
			    <th>Title</th>	
				<th>Title</th>
				<th>Amount</th>
				<th>Date</th>
			</tr>
		</thead>
		<tbody>
			<?php 
			$sql_query = "SELECT title, amount, date FROM Expense LIMIT 10";
			$resultset = mysqli_query($conn, $sql_query) or die("database error:". mysqli_error($conn));
			while( $expense = mysqli_fetch_assoc($resultset) ) {
			?>
			   <tr> 
			   	<td><?php echo $expense ['title']; ?></td>
			   <td><?php echo $expense ['title']; ?></td> 
			   <td><?php echo $expense ['amount']; ?></td>
			   <td><?php echo $expense ['date']; ?></td>   
			   </tr>
			<?php } ?>
		</tbody>
    </table>
    <div style="margin:50px 0px 0px 0px;">
		<a class="btn btn-default read-more" style="background:#3399ff;color:white" href="">Back to Statement</a>		
	</div>

</div>

<?php include('footer.php');?>
 



                                                                                                       