<?php
include_once("db_connect.php");
$input = filter_input_array(INPUT_POST);
if ($input['action'] == 'edit') {	
	$update_field='';
	if(isset($input['title'])) {
		$update_field.= "title='".$input['title']."'";
	} else if(isset($input['amount'])) {
		$update_field.= "amount='".$input['amount']."'";
	} else if(isset($input['date'])) {
		$update_field.= "date='".$input['date']."'";
	} 	
	if($update_field && $input['id']) {
		$sql_query = "UPDATE income SET $update_field WHERE id='" . $input['id'] . "'";	
		mysqli_query($conn, $sql_query) or die("database error:". mysqli_error($conn));		
	}
}

