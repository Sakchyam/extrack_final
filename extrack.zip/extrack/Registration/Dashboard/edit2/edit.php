<?php
// include database connection file
include_once("config.php");

// Check if form is submitted for user update, then redirect to homepage after update
if(isset($_POST['update']))
{	
	$id = $_POST['id'];
	
	$title=$_POST['title'];
	$amount=$_POST['amount'];
	$date=$_POST['date'];
		
	// update user data
	$result = mysqli_query($mysqli, "UPDATE expense SET title='$title',amount='$amount',date='$date' WHERE id=$id");
	
	// Redirect to homepage to display updated user in list
	header("Location: index.php");
}
?>
<?php
// Display selected user data based on id
// Getting id from url
$id = $_GET['id'];

// Fetech user data based on id
$result = mysqli_query($mysqli, "SELECT * FROM expense WHERE id=$id");

while($user_data = mysqli_fetch_array($result))
{
	$title= $user_data['title'];
	$amount = $user_data['amount'];
	$date = $user_data['date'];
}
?>
<html>
<head>	
	<title>Edit User Data</title>
	<link href="edit.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css" />
</head>

<body>
	
	<div class="container">
	<h2 style="text-align: center;">Edit Data</h2>
	<form name="update_user" method="post" action="edit.php">
		<table class="table">
			<tr> 
				<td>Title</td>
				<td><input type="text" name="title" value=<?php echo $title;?>> </td>
			</tr>
			<tr> 
				<td>Amount</td>
				<td><input type="float" name="amount" value=<?php echo $amount;?>> </td>
			</tr>
			<tr> 
				<td>Date</td>
				<td><input type="date" name="date" value=<?php echo $date;?>></td>
			</tr>
			<tr>
				<td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
	<a class="btn" href="index.php">Back to Table</a>
	</div>
</body>
</html>

