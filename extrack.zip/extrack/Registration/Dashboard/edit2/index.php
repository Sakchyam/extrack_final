<?php
// Create database connection using config file
include_once("config.php");

// Fetch all users data from database
session_start();
$uid=$_SESSION['username'];
$result = mysqli_query($mysqli, "SELECT * FROM expense WHERE username='$uid'");
?>

<html>
<head>    
    <title>Table Edit</title>
    <link href="tablestyle.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css" />
</head>

<body>
<div class="container">	
	<h1>Expense Table</h1>		 
	<table id="data_table" class="table">
		<thead>
			<tr>
				<th>Title</th>
				<th>Amount</th>
				<th>Date</th>
                <th>Tools</th>
			</tr>
		</thead>
        <?php  
        while($user_data = mysqli_fetch_array($result)) {         
        echo "<tr>";
        echo "<td>".$user_data['title']."</td>";
        echo "<td>".$user_data['amount']."</td>";
        echo "<td>".$user_data['date']."</td>";    
        echo "<td><a href='edit.php?id=$user_data[id]'>Edit</a> 
         <a href='delete.php?id=$user_data[id]'>Delete</a></td></tr>";        
        }
        ?>
    </table>
        <div style="margin:40px 0px 0px 0px;">
		<a class="btn" href="../profilecard.php">Back to Statement</a>		
	    </div>
</div>
</body>
</html>
