<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title></title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css"/>
  <link href="stylep.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css" />
</head>
<body>


<a href="dashboard.php" class="back-btn"> Back to Dashboard</a>
  <div class="profile-card">
    <div class="card-header">
      <div class="name">
        Welcome to Extrack <br>
          <?php session_start();   if (isset($_SESSION['username'])) : ?>
          <?php echo $_SESSION['username']; ?>
          <?php endif ?>
        

      </div>
     
    </div> 
    <div class="card-footer">

      <div class="numbers">
        <div class="item" style="color: green;">
          <span> 
            <?php 
                  $con = mysqli_connect('localhost','root','','registration');
                  $uid=$_SESSION['username'];
                  $result= mysqli_query($con,"SELECT SUM(amount) AS totalsum FROM income WHERE username='$uid'"); 
                  $row = mysqli_fetch_assoc($result); 
                  $sum = $row['totalsum'];
                  echo ("Rs $sum"); 
            ?> 
          </span> 
                  INCOME
        </div>
        <div class="border"></div>
        <div class="item" style="color: red;">
          <span> 
            <?php 
            $con = mysqli_connect('localhost','root','','registration');
            $uid=$_SESSION['username'];
            $result= mysqli_query($con,"SELECT SUM(amount) AS totalsum FROM expense WHERE username='$uid'"); 
            $row = mysqli_fetch_assoc($result); 
            $sum1 = $row['totalsum']; 
            echo ("Rs $sum1");
            ?> 
          </span>
          EXPENSE
        </div>
        <div class="border"></div>
        <div class="item" style="color: black;">
          <span> Rs 
          <?php 
          $bal= $sum - $sum1;
          echo $bal; 
          ?>
          </span>
          SAVINGS
        </div>
      </div>
    </div>
  </div>


  <div class="date">
     <a href="edit2\index.php" class="edit-btn"> Edit Expense</a>
     <a href="edit1\index.php" class="edit-btn"> Edit Income</a>
    </div>

  </div>



  <div class="recommend">
    <div class="rtitle">
    <?php 
     if ($bal <= 0) {
      echo "Recommendation:"; 
      echo "<br>";
      echo "You don't have enough funds";
     }

     else if ($bal <= 10000) {
      echo "Recommendation:";
      echo "<br>";
      echo "Based on your current savings, we recommend you to wait and let your wealth grow.";
     } 
     else if ($bal <= 50000) {
      echo "Recommendation:";
      echo "<br>";
      echo "Based on your current savings, we recommend you to invest in gold/silver.";
     }
     else if ($bal <= 100000){

    echo "Recommendation:";
    echo "<br>";
    echo"Based on your current savings, we recommend you to invest in the Stock Market/Cryptocurrency. ";
     } 

     else if ($bal <= 1000000){

    echo "Recommendation:";
    echo "<br>";
    echo"Based on your current savings, we recommend you to invest in Land. ";
     } 
   else if ($bal > 1000000){

    echo "Recommendation:";
    echo "<br>";
    echo"Based on your current savings, we recommend you to make multiple investments in Gold, Land, Cryptocurrency and more. ";
     } 
    ?> 

    
</div>
</div>
</body>
</html>