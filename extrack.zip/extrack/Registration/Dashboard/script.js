const options ={
	bottom: '32px', // default: '32px'
  left: 'unset', // default: '32px'
  right: '35px', // default: 'unset'
  time: '0.5s', // default: '0.3s'
  mixColor: 'white', // default: '#fff'
  backgroundColor: 'black',  // default: '#fff'
  buttonColorDark: 'white',  // default: '#100f2c'
  buttonColorLight: 'black', // default: '#fff'
  saveInCookies: false, // default: true,
  autoMatchOsTheme: true // default: true
}

const darkmode = new Darkmode(options);
darkmode.showWidget();