<?php
include_once 'database.php';
session_start();
if(isset($_POST['save']))
{	 
	 
	 $title = $_POST['title'];
	 $amount = $_POST['amount'];
	 $uname= $_SESSION['username'];
	 $sql = "INSERT INTO `expense` (`title`, `amount`,`date`,`username`) VALUES ('$title',$amount,now(),'$uname')";
	 if (mysqli_query($conn, $sql)) {
		echo header("Location: http://localhost/extrack/Registration/Dashboard/Input/index.php");
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}

?>