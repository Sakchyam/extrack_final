<!DOCTYPE html>
<html>
<head>
	<title>Ex Track</title>
	<link rel="stylesheet" type="text/css" href="home.css">
	<header>
		<div class="main">

			<ul>
				<li class="active"> <a href="#"> Home </a></li>
				<li> <a href="Registration/login.php"> Login </a></li>
				<li> <a href="Registration/register.php"> Signup </a></li>
				<li> <a href="contact.html"> Contact </a></li>
			</ul>
		</div>
		
		<div class="title">
				<h1>ExTrack</h1>
				<h2>We Track your finance!</h2>
		</div>

		<div class="button">
			<a href="learnmore.html" class="btn"> Learn More </a>
		</div>

	</header>
</head>

<body>

</body>

</html>